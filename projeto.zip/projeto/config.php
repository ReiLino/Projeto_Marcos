<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('BASE', 'livroreceitas');

$conn = new MySQLi(HOST,USER,PASS,BASE);