<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', 'user');
define('BASE', 'livroreceitas');

$conn = new MySQLi(HOST,USER,PASS,BASE);